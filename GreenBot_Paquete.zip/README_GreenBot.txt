Paquete GreenBot - incluye app, excel y requirements.
